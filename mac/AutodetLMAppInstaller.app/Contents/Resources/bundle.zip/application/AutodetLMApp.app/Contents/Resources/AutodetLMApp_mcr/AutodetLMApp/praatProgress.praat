form: "Set progress"
    real: "Progress", "0"
endform

barmax = 20
barfill = round(progress * barmax)

loadbar$ = "["

for i to barfill
    loadbar$ = loadbar$ + "@"
endfor

for i from barfill to barmax
    loadbar$ = loadbar$ + " "
endfor 

loadbar$ = loadbar$ + "]"

writeInfoLine: "Detecting Landmarks" + dots$ [index] 
appendInfoLine: loadbar$
